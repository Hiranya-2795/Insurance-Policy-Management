﻿using Microsoft.AspNetCore.Mvc;
using InsuranceApi.Data;
using InsuranceApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;

namespace InsuranceApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserProfileController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<UserProfileController> _logger;

        // Constructor with dependency injection for logging
        public UserProfileController(AppDbContext context, ILogger<UserProfileController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/UserProfile
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetUserProfiles()
        {
            var users = await _context.UserProfiles
                .Select(u => new
                {
                    u.UserID,
                    u.FullName,
                    u.DateOfBirth,
                    u.Gender,
                    u.PhoneNumber,
                    u.Email,
                    u.AadharNumber,
                    u.Role
                })
                .ToListAsync();

            return Ok(users);
        }

        // GET: api/UserProfile/5
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetUserProfile(int id)
        {
            var user = await _context.UserProfiles.FindAsync(id);

            if (user == null)
                return NotFound();

            return Ok(new
            {
                user.UserID,
                user.FullName,
                user.DateOfBirth,
                user.Gender,
                user.PhoneNumber,
                user.Email,
                user.AadharNumber,
                user.Role
            });
        }

        // POST: api/UserProfile
        [HttpPost]
        public async Task<ActionResult<UserProfile>> PostUserProfile(UserProfile userProfile)
        {
            if (string.IsNullOrWhiteSpace(userProfile.Password))
                return BadRequest("Password is required.");

            _logger.LogInformation("Before salt generation.");

            // Generate salt
            userProfile.Salt = GenerateSalt();

            // Log the generated salt
            _logger.LogInformation($"Generated Salt: {userProfile.Salt}");

            // Hash the password along with the salt
            userProfile.PasswordHash = HashPassword(userProfile.Password + userProfile.Salt);

            // We no longer need to set userProfile.Password to null, as it doesn't exist anymore in the model

            _context.UserProfiles.Add(userProfile);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetUserProfile), new { id = userProfile.UserID }, userProfile);
        }

        // PUT: api/UserProfile/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUserProfile(int id, UserProfile userProfile)
        {
            if (id != userProfile.UserID)
                return BadRequest("User ID mismatch");

            var existingUser = await _context.UserProfiles.FindAsync(id);
            if (existingUser == null)
                return NotFound();

            // Update only the provided fields
            existingUser.FullName = userProfile.FullName ?? existingUser.FullName;
            existingUser.DateOfBirth = userProfile.DateOfBirth ?? existingUser.DateOfBirth;
            existingUser.Gender = userProfile.Gender ?? existingUser.Gender;
            existingUser.PhoneNumber = userProfile.PhoneNumber ?? existingUser.PhoneNumber;
            existingUser.Email = userProfile.Email ?? existingUser.Email;
            existingUser.AadharNumber = userProfile.AadharNumber ?? existingUser.AadharNumber;
            existingUser.Role = userProfile.Role ?? existingUser.Role;

            if (!string.IsNullOrWhiteSpace(userProfile.Password))
            {
                existingUser.Salt = GenerateSalt();
                existingUser.PasswordHash = HashPassword(userProfile.Password + existingUser.Salt);
            }

            await _context.SaveChangesAsync(); // No need to mark entity as modified manually

            return NoContent();
        }


        // DELETE: api/UserProfile/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserProfile(int id)
        {
            var user = await _context.UserProfiles.FindAsync(id);
            if (user == null)
                return NotFound();

            // Check for related data
            var hasPolicies = _context.UserPolicies.Any(p => p.UserID == id);
            if (hasPolicies)
                return BadRequest("User has associated policies.");

            _context.UserProfiles.Remove(user);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Simple salt + hash (you can use stronger logic)
        private string GenerateSalt() => Guid.NewGuid().ToString();
        private string HashPassword(string input) => BCrypt.Net.BCrypt.HashPassword(input);
    }
}

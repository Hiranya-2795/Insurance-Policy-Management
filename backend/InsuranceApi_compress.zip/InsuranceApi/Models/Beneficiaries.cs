﻿namespace InsuranceApi.Models
{
    public class Beneficiaries
    {
    }
}
